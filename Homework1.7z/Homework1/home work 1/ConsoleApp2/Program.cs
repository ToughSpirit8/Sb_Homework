﻿using static System.Console;
namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            WriteLine("Hello, World!");
            Write("Hell");
            Write("o, ");
            Write("World");
            Write("!");
            ReadLine();
        }
    }
}